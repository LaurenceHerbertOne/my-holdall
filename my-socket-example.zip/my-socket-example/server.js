//-------------------------------------------------------
//-------------------------------------------------------
// code adapted to extend My socket.io example to include 
// messaging functionality and follows tutorial at
// - server-side
//-------------------------------------------------------
//-------------------------------------------------------

// server.js

//contains the web server code (server-side code)
// - set up an Express web server
var express = require('express');  
var app = express();  
var server = require('http').createServer(app);
var io = require('socket.io')(server);


// Express can server static files - JavaSript, CSS, image files
app.use(express.static(__dirname + '/public'));

//fixes cannot GET error in browser by adding a route  redirect '/' to index.html file
app.get('/', function(req, res, next) {  
    res.sendFile(__dirname + '/public/index.html');
});

//when a client connects / disconnects / closes browser, output appropriate message in terminal
io.on('connection', function(client) { 
    console.log('user connected...');
    client.on('chat message', function(msg) {
        console.log('message: ' + msg);
        io.emit('chat message', msg);
    });
    
    // firing a disconnect event (on page refresh or page close)
    client.on('disconnect', function() {
        console.log('user disconnected...');
    });
});
	
//start web server and socket.io server listening
server.listen(3000, function(){
  console.log('listening on *:3000');
});


//------------------------------------------------
//------------------------------------------------
// My socket.io example - this code implements
// correctly to update button clicks among 
// multiple users and is folowing this sample - 
// https://github.com/aerrity/socket-click-example 
//------------------------------------------------
//------------------------------------------------

//var express = require('express');  
//var app = express();  
//var server = require('http').createServer(app);
//var io = require('socket.io')(server);
// track how may times button is clicked
//var clickCount = 0;
//
//
//// Express can server static files - JavaSript, CSS, image files
//app.use(express.static(__dirname + '/public'));
//
////fixes cannot GET error in browser by adding a route  redirect '/' to index.html file
//app.get('/', function(req, res, next) {  
//    res.sendFile(__dirname + '/public/index.html');
//});
//
////when a client connects, function will output appropriate message in terminal
//io.on('connection', function(client) {  
//    console.log('new connection...');
//    // increment clickCount variable and display updated value to all connected clients
//    client.on('clicked', function(data) {
//	  clickCount++;
//	  //send a message to ALL connected clients
//	  io.emit('buttonUpdate', clickCount);
//    });
//});
//	
////start web server and socket.io server listening
//server.listen(3000, function(){
//  console.log('listening on *:3000');
//});
